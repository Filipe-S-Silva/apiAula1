//npm init
//npm i
//npm init -y
//npm i axios

const axios = require('axios');
const url = "https://jsonplaceholder.typicode.com/todos/1";

//GET
axios.get(url)
    .then(response => {
        //Dados recebidos da API 
        console.log("Dados recebidos da API: ")
        console.log(response.data)
    })
    .catch(error => {
        //Tratamento de erro
        console.log(`Erro ao acessar a API: ${error}`)
    })

