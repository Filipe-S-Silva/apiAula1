const axios = require('axios');
const url = "https://jsonplaceholder.typicode.com/posts";

const novoPost = {
    title: "Filipe é lindo",
    body: "Preto lindo D+, tu é doido", 
    userId: 1
}

//POST  
axios.post(url, novoPost)
    .then(response => {
        console.log("Recurso criado com sucesso: ")
        console.log(response.data)
    })
    .catch(error => {
        console.log(`Erro: ${error}`)
    })